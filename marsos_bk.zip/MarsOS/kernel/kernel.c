#include "../cpu/isr.h"
#include "../drivers/screen.h"
#include "../drivers/vga.h"
#include "kernel.h"
#include "../libc/string.h"
#include "../libc/mem.h"
#include <stdint.h>


uint8 inb(uint16 port)
{
  uint8 data;
  asm volatile("inb %1, %0" : "=a"(data) : "Nd"(port));
  return data;
}

void outb(uint16 port, uint8 data)
{
  asm volatile("outb %0, %1" : : "a"(data), "Nd"(port));
}

void kernel_main() {
    isr_install();
    irq_install();

    asm("int $2");
    asm("int $3");
    //clear_screen();
    kprint(". ___  ___                   _____  _____  \n");
    kprint(". |  \/  |                  |  _  |/  ___| \n");
    kprint(". | .  . |  __ _  _ __  ___ | | | |\ `--.  \n");
    kprint(". | |\/| | / _` || '__|/ __|| | | | `--. \ \n");
    kprint(". | |  | || (_| || |   \__ \\ \_/ //\__/ / \n");
    kprint(". \_|  |_/ \__,_||_|   |___/ \___/ \____/  \n"); 
    kprint("Welcome to MarsOS!!! by >>> Alderrden.\n"
        "Write HELP if you wont found comand.\n> ");
}

void user_input(char *input) {
    if (strcmp(input, "END") == 0) {
        kprint("Stopping the CPU. Bye!\n");
        asm volatile("hlt");
    }
    if (strcmp(input, "PAGE") == 0) {
        uint32_t phys_addr;
        uint32_t page = kmalloc(1000, 1, &phys_addr);
        char page_str[16] = "";
        hex_to_ascii(page, page_str);
        char phys_str[16] = "";
        hex_to_ascii(phys_addr, phys_str);
        kprint("Page: ");
        kprint(page_str);
        kprint(", physical address: ");
        kprint(phys_str);
        kprint("\n");
    }
    
    if (strcmp(input, "HELP") == 0) {
        kprint("MarsOS Help list:\n");
        kprint("\nPAGE - physical address");
        kprint("\nEND - Stopping the CPU");
        kprint("\nVER - Version, mod and more info");  
        kprint("\nCLEAR - Clear screen");
    }
    
    if (strcmp(input, "VER") == 0) {
       kprint("\nMarsOS by alderrden");
       kprint("\nVersion: 0.0.1 demo (2021)");
       kprint("\nNo vesa mod");
    }
    
    //if (strcmp(input, "CLEAR") == 0) {
    //   clear_screen();
    //   kprint("\n> ");
    //}

    if (strcmp(input, "VGA") == 0) {
        init_vga();
        draw_rect(0, 0, VGA_MAX_WIDTH - 1, VGA_MAX_HEIGHT - 1, BRIGHT_GREEN);
        draw_rect(2, 2, 30, 30, YELLOW);
        draw_rect(VGA_MAX_WIDTH - 33, 2, 30, 30, YELLOW);
        draw_rect(2, VGA_MAX_HEIGHT - 33, 30, 30, YELLOW);
        draw_rect(VGA_MAX_WIDTH - 33, VGA_MAX_HEIGHT - 33, 30, 30, YELLOW);
        draw_diamond(16, 16, 10, BRIGHT_CYAN);
        draw_diamond(VGA_MAX_WIDTH - 18, 16, 10, BRIGHT_CYAN);
        draw_diamond(16, VGA_MAX_HEIGHT - 18, 10, BRIGHT_CYAN);
        draw_diamond(VGA_MAX_WIDTH - 18, VGA_MAX_HEIGHT - 18, 10, BRIGHT_CYAN);      

        draw_line(VGA_MAX_WIDTH / 2, 0, VGA_MAX_WIDTH / 2, VGA_MAX_HEIGHT, BRIGHT_GREEN);      

        for(uint16 i = 0; i < 50; i+=3){
          draw_circle(80, 100, 50-i, BRIGHT_RED);
        }      

        for(uint16 i = 0; i < 50; i+=3){
          draw_diamond(240, 100, 50-i, BRIGHT_MAGENTA);
        }
    }
    else {
        kprint("Command not found: ");
        kprint(input) ;
    }
    kprint("\n> ");
}
